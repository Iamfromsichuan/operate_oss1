# 项目说明
基于iview和vue2开发的一套完整的后台管理框架，提供了登陆验证、权限验证等功能

## 安装依赖
npm install
## 本地运行
npm run dev 
## 上线打包
npm run build

