// Exports the "textpattern" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/textpattern')
//   ES2015:
//     import 'tinymce/plugins/textpattern'
require('./plugin.js');
