<template>

</template>

<script>
    export default {
        name: 'messageUpCQ'
    };
</script>

<style scoped>

</style>
