<!--各个省份的  短信上行  功能  全部集成到此页面-->
<template>
    <div class="messageList">
        <Row :gutter="10">
            <Col span="2">
                <Input placeholder="订单来源" style="width: 100%" v-model="filter.provinceCode"></Input>
            </Col>
            <Col span="2">
                <Input placeholder="订单类型" style="width: 100%" v-model="filter.productType"></Input>
            </Col>
            <Col span="2">
                <Input placeholder="请输入网别" style="width: 95%" v-model="filter.netStop"></Input>
            </Col>
            <Col span="5">
                <DatePicker :value="initTime" type="datetimerange" placement="bottom-start" placeholder="导入时间" style="width: 100%" @on-change="changeTime"></DatePicker>
            </Col>
            <Col span="3">
                <Input placeholder="电话号码" style="width: 100%" v-model="filter.mobileNumber"></Input>
            </Col>
            <Col span="3">
                <Select clearable v-model="CodeAndName" filterable placeholder="请选择省份名称">
                    <Option v-for="item in items" :value="item.dictionaryCode" :key="item.dictionaryCode">{{ item.dictionaryName }}</Option>
                </Select>
            </Col>
            <Col span="3">
                <Select clearable v-model="filter.procStatus" filterable placeholder="请选择处理状态">
                    <Option value="-1" :key="">未处理</Option>
                    <Option value="1" :key="">成功</Option>
                    <Option value="2" :key="">无效</Option>
                </Select>
            </Col>
            <Col span="4">
                <Button type="primary" icon="ios-search" @click="search(1)">查找</Button>
                <Button type="success" icon="ios-cloud-download" @click="download">导出</Button>
            </Col>
        </Row>
        <br>
        <Table :columns="columns" :data="datas" :loading="dataLoading"></Table>
        <br>
        <Page :total="totalRecords" :current="filter.pageNo" @on-change='changePage' :page-size="filter.pageSize"></Page>
        <br>
        <Modal
                v-model="modal1"
                width="800"
                @on-ok="ok"
                @on-cancel="cancel">
            <p slot="header" style="color:#f60;text-align:center">
                <Icon type="information-circled"></Icon>
                <span>详情展示</span>
            </p>
            <Table border :columns="columns1" :data="objectList"></Table>
            <!--<div v-for="(item,key) in objectList" style="width: 50%;display: inline-block">

            </div>-->
        </Modal>
    </div>
</template>

<script>
    import Cookies from 'js-cookie'
    import util from '@/libs/util'
    import {ERR_OK,pageSize} from '@/config/config'
    export default {
        data () {
            return {
                modal1:false,
                items:"",
                CodeAndName:"",
                initTime: [`${new Date().getFullYear()}-${new Date().getMonth() + 1}-${new Date().getDate()} 00:00:00`, `${new Date().getFullYear()}-${new Date().getMonth() + 1}-${new Date().getDate()} 23:59:59`],
                filter: {
                    mobileNumber:"",//电话号码
                    startTime: '',
                    endTime: '',
                    productType:"",//产品类型
                    provinceName:"",//来源
                    netStop:"",//网别
                    orderStatus:"",//订单状态
                    provinceCode:"",//省份
                    pageNo:1,
                    pageSize: pageSize
                },
                objectList:[],
                totalRecords: 0,
                dataLoading: false,
                columns1:[
                    {
                        title: '',
                        key: 'title',
                    },

                    {
                        title: '',
                        key: 'name',
                    },
                ],
                columns: [
                    {
                        title: '电话号码',
                        key: 'mobileNumber',
                    },
                    {
                        title: '网别',
                        key: 'netStop'
                    },
                    {
                        title: '订单来源',
                        key: 'orderSource'
                    },
                    {
                        title: '产品类型',
                        key: 'productType'
                    },
                    {
                        title: '订单状态',
                        key: 'orderStatus'
                    },
                    {
                        title: '省份编码',
                        key: 'provinceCode'
                    },
                    {
                        title: '短信内容',
                        key: 'smsContent'
                    },
                    {
                        title: '返回时间',//
                        key: 'responseTime',
                        align: 'center',
                        width:200
                    },
                    {
                        title: '返回状态',
                        key: 'responseData'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 150,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'warning',
                                        size: 'small'
                                    },
                                    on: {
                                        click:()=>{
                                            let _that = this;//foundColumns
                                            _that.objectList  = [];
                                            for(let i in params.row) {
                                                for(let b = 0; b< _that.foundColumns.length ; b++ ) {
                                                    if(i === _that.foundColumns[b].key) {
                                                        let obj = {};
                                                        obj.name = params.row[i];
                                                        _that.objectList.push(Object.assign({},_that.foundColumns[b],obj))
                                                    }
                                                }
                                            }
                                            this.modal1 = true
                                        }
                                    }
                                }, '查看详情'),
                            ]);
                        }
                    }

                ],
                foundColumns: [
                    {
                        title: '电话号码',
                        key: 'mobileNumber',
                    },
                    {
                        title: '网别',
                        key: 'netStop'
                    },
                    {
                        title: '订单来源',
                        key: 'orderSource'
                    },
                    {
                        title: '产品类型',
                        key: 'productType'
                    },
                    {
                        title: '订单状态',
                        key: 'orderStatus'
                    },
                    {
                        title: '省份编码',
                        key: 'provinceCode'
                    },
                    {
                        title: '短信内容',
                        key: 'smsContent'
                    },
                    {
                        title: '返回时间',//
                        key: 'responseTime',
                        align: 'center',
                        width:200
                    },
                    {
                        title: '返回状态',
                        key: 'responseData'
                    },
                     {
                         title: '订单号',
                         key: 'orderNo'
                     },
                     {
                         title: '开始时间',
                         key: 'startTime'
                     },
                     {
                         title: '结束时间',
                         key: 'endTime'
                     },
                     {
                         title: '产品编码',
                         key: 'productCode',
                     },
                     {
                         title: '流水号',
                         key: 'transId',
                     },


                     {
                         title: '产品名称',
                         key: 'productName'
                     },

                     {
                         title: '通道编码',
                         key: 'passagewayCode'
                     },
                     {
                         title: '渠道类型',
                         key: 'channelType'
                     },
                     {
                         title: '附加数据',
                         key: 'attachData'
                     },
                     {
                         title: '充值策略',
                         key: 'rechargeStrategy'
                     },
                     {
                         title: '充值策略数据',
                         key: 'rechargeStrategyData'
                     },
                     {
                         title: '充值路径',
                         key: 'rechargeProfile'
                     },
                     {
                         title: '充值索引',
                         key: 'rechargeIndex'
                     },

                     {
                         title: '订单内容',
                         key: 'orderContent'
                     },

                     {
                         title: '请求数据',
                         key: 'requestData'
                     },
                     {
                         title: '响应数据',
                         key: 'responseData'
                     },

                     {
                         title: '创建时间',
                         key: 'createTime'
                     },

                     {
                         title: '查单请求数据',
                         key: 'queryRequestData'
                     },
                     {
                         title: '查单响应数据',
                         key: 'queryResponseData'
                     },
                     {
                         title: '备注',
                         key: 'remarks'
                     },

                ],
                datas: []
            }
        },
        methods: {
            ok() {

            },
            cancel() {

            },
            changeTime(time) {
                if(time.length) {
                    this.filter.startTime = time[0]
                    this.filter.endTime = time[1]
                }else {
                    this.filter.startTime = ''
                    this.filter.endTime = ''
                }
            },
            search(no) {
                var _that = this
                this.filter.pageNo = no
                this.dataLoading = true
                util.ajax.get(util.baseUrl + '/core/orders/list', {
                    params: this.filter
                })
                    .then(function(res){
                        console.log(res)
                        if(res.status == ERR_OK) {
                            _that.datas = res.data
                            _that.totalRecords = res.data.length
                            _that.dataLoading = false
                        }else {
                            _that.$Message.error(res)
                            _that.dataLoading = false
                        }
                    })
                    .catch(function(err){
                        console.log(err);
                    });
            },
            changePage(no) {
                this.search(no)
            },
            download() {
                window.location.href = util.baseUrl + '/core/orders/export?token='+Cookies.get('token') + util.parseParam(this.filter)
            },
            getProvinceName(name){
                var _that = this
                util.ajax.get(util.baseUrl + '/system/data/dictionary/list',{
                    params:{
                        dictionaryType:name
                    }
                })
                    .then(function(res){
                        console.log(res)
                        _that.items = res.data
                        _that.dataLoading = false
                    })
                    .catch(function(err){
                        console.log(err);
                    });
            }
        },
        created() {
            this.filter.startTime = this.initTime[0]
            this.filter.endTime = this.initTime[1]
            this.getProvinceName("省份");
        }
    }
</script>

<style lang="less">

</style>
